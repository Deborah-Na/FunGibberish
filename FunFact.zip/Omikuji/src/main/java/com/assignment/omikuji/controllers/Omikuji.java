package com.assignment.omikuji.controllers;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Omikuji {
	
	@RequestMapping("/")
	public String form() {
	
		return "index.jsp";
}
	@PostMapping(value="/process")
	public String processOmikuji(HttpSession session,
			@RequestParam(value="number") Integer number,
			@RequestParam(value="person_name") String person_name,
			@RequestParam(value="cityname") String cityname,
			@RequestParam(value="hobby") String hobby,
			@RequestParam(value="animal") String animal,
			@RequestParam(value="food") String food,
			@RequestParam (value="nice_word") String nice_word
			) {
		session.setAttribute("number", number);
		session.setAttribute("person_name", person_name);
		session.setAttribute("cityname", cityname);
		session.setAttribute("hobby", hobby);
		session.setAttribute("animal", animal);
		session.setAttribute("food", food);
		session.setAttribute("nice_word", nice_word);
		return "redirect:/results";
	}
	
	public String name(HttpSession session) {        
		session.setAttribute("cityname", "Deborah");
		return "results.jsp";
	}
	@RequestMapping("/results")
	public String confirm(HttpSession session, Model model) {
//		Omikuji currentResult = new Omikuji();
//		model.addAttribute("cityname", session.getAttribute("cityname"));
		if (session.getAttribute("fortune") == null) {
			session.setAttribute("fortune", "Deborah");
		} else {
			Integer number = (Integer) session.getAttribute("number");
			String person_name = (String) session.getAttribute("person_name");
			String cityname = (String) session.getAttribute("cityname");
			String hobby = (String) session.getAttribute("hobby");
			String animal = (String) session.getAttribute("animal");
			String food = (String) session.getAttribute("food");
			String nice_word = (String) session.getAttribute("nice_word");
			System.out.println(animal);
			
			model.addAttribute("number", number);
			model.addAttribute("person_name", person_name);
			model.addAttribute("cityname", cityname);
			
			model.addAttribute("hobby", hobby);
			model.addAttribute("animal", animal);
			model.addAttribute("food", food);
			model.addAttribute("nice_word", nice_word);
		}
		return "results.jsp";
	}
	
	
	
}
